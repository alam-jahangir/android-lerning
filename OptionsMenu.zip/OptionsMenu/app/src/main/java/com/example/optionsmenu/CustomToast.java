package com.example.optionsmenu;

import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Gravity;
import android.view.View;

public class CustomToast {

    public static void showCustomTost(Toast toast, View layout) {
        TextView tv = (TextView) layout.findViewById(R.id.txtvw);
        tv.setText("Custom Toast Notification");
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 100);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }
}
