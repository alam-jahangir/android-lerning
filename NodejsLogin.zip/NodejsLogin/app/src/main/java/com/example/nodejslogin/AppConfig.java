package com.example.nodejslogin;

public class AppConfig {

    // Server API URL
    public static String API_URL = "http://192.168.53.152:3000/api";

}
